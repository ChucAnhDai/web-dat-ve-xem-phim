// ===== SHARED DATA =====
const statusColors = {
  'Completed':'green','Active':'green','Now Showing':'green','Delivered':'green','Confirmed':'blue',
  'Pending':'orange','Coming Soon':'blue','Shipped':'blue',
  'Cancelled':'red','Ended':'gray','Refunded':'purple',
  'Renovation':'orange','Suspended':'red',
  'Admin':'red','Staff':'gold','Customer':'gray',
  'Success':'green','Failed':'red','Low':'orange',
};

function statusBadge(s) {
  const c = statusColors[s] || 'gray';
  return `<span class="badge ${c}"><div class="badge-dot"></div>${s}</span>`;
}

function stars(r) {
  if (!r) return '<span style="color:var(--text-dim);font-size:11px;">No rating</span>';
  let html = '<div class="stars">';
  for(let i=1;i<=5;i++) html += `<span class="star ${i<=Math.round(r)?'':'empty'}">★</span>`;
  return html + `<span style="font-size:11px;color:var(--text-muted);margin-left:4px;">${r}</span></div>`;
}

// ===== TOAST =====
function showToast(message, type='info') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    container.id = 'toastContainer';
    document.body.appendChild(container);
  }
  const icons = {
    success:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>',
    error:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
    info:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
    warning:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
  };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="toast-icon">${icons[type]||icons.info}</div>
    <div class="toast-text">${message}</div>
    <div class="toast-close" onclick="this.parentNode.remove()">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
    </div>`;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity='0'; toast.style.transform='translateX(20px)'; toast.style.transition='all 0.3s'; setTimeout(()=>toast.remove(),300); }, 3500);
}

// ===== SIDEBAR =====
let sidebarCollapsed = false;
function toggleSidebar() {
  if (window.innerWidth <= 768) {
    document.getElementById('sidebar').classList.toggle('mobile-open');
    document.getElementById('sidebarOverlay').classList.toggle('active');
  } else {
    sidebarCollapsed = !sidebarCollapsed;
    document.getElementById('sidebar').classList.toggle('collapsed', sidebarCollapsed);
    document.getElementById('mainWrap').classList.toggle('collapsed', sidebarCollapsed);
  }
}
function closeMobileSidebar() {
  document.getElementById('sidebar').classList.remove('mobile-open');
  document.getElementById('sidebarOverlay').classList.remove('active');
}

// ===== MODAL =====
function openModal(titleText, bodyHTML) {
  document.getElementById('modalTitle').textContent = titleText;
  document.getElementById('modalBody').innerHTML = bodyHTML;
  document.getElementById('modalOverlay').classList.add('open');
}
function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
}
function handleModalSave() {
  closeModal();
  showToast('Changes saved successfully!', 'success');
}

// ===== PAGINATION =====
function buildPagination(infoText, total=10) {
  return `
  <div class="pagination">
    <div class="pagination-info">${infoText}</div>
    <div class="pagination-btns">
      <button class="pg-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg></button>
      <button class="pg-btn active">1</button>
      <button class="pg-btn" onclick="showToast('Page 2','info')">2</button>
      <button class="pg-btn" onclick="showToast('Page 3','info')">3</button>
      ${total>3?`<button class="pg-btn">...</button><button class="pg-btn">${total}</button>`:''}
      <button class="pg-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></button>
    </div>
  </div>`;
}

// ===== COMMON MOVIE FORM BODY =====
function movieFormBody(m={}) {
  return `
  <div class="form-grid">
    <div class="field"><label>Movie Title</label><input class="input" placeholder="Enter movie title" value="${m.title||''}"></div>
    <div class="field"><label>Category</label><select class="select"><option>Action</option><option>Drama</option><option>Comedy</option><option>Horror</option><option>Sci-Fi</option><option>Animation</option><option>Romance</option><option>Thriller</option></select></div>
    <div class="field"><label>Duration (min)</label><input class="input" type="number" placeholder="120" value="${m.dur||''}"></div>
    <div class="field"><label>Release Date</label><input class="input" type="date" value="${m.release||''}"></div>
    <div class="field"><label>Rating</label><input class="input" type="number" placeholder="0.0" min="0" max="5" step="0.1" value="${m.rating||''}"></div>
    <div class="field"><label>Status</label><select class="select"><option>Coming Soon</option><option>Now Showing</option><option>Ended</option></select></div>
    <div class="field"><label>Language</label><input class="input" placeholder="English, Vietnamese" value="${m.lang||''}"></div>
    <div class="field"><label>Trailer URL</label><input class="input" placeholder="https://youtube.com/..."></div>
    <div class="field form-full"><label>Description</label><textarea class="textarea" placeholder="Enter movie description...">${m.desc||''}</textarea></div>
    <div class="field form-full"><label>Poster Image</label>
      <div class="upload-zone" onclick="showToast('File picker opened','info')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        <p>Drop file here or <span>browse</span></p>
        <p style="font-size:11px;margin-top:4px;color:var(--text-dim);">PNG, JPG up to 5MB</p>
      </div>
    </div>
  </div>`;
}

// ===== COMMON PRODUCT FORM BODY =====
function productFormBody(p={}) {
  return `
  <div class="form-grid">
    <div class="field"><label>Product Name</label><input class="input" placeholder="Enter product name" value="${p.name||''}"></div>
    <div class="field"><label>Category</label><select class="select"><option>Snacks</option><option>Beverages</option><option>Merchandise</option><option>Combos</option></select></div>
    <div class="field"><label>Price ($)</label><input class="input" type="number" placeholder="0.00" value="${p.price||''}"></div>
    <div class="field"><label>Stock Qty</label><input class="input" type="number" placeholder="0" value="${p.stock||''}"></div>
    <div class="field"><label>Brand</label><input class="input" placeholder="Brand name" value="${p.brand||''}"></div>
    <div class="field"><label>Weight (g)</label><input class="input" placeholder="0"></div>
    <div class="field"><label>Origin</label><input class="input" placeholder="Country of origin"></div>
    <div class="field"><label>SKU</label><input class="input" placeholder="CS-001"></div>
    <div class="field form-full"><label>Description</label><textarea class="textarea" placeholder="Product description...">${p.desc||''}</textarea></div>
    <div class="field form-full"><label>Product Images</label>
      <div class="upload-zone" onclick="showToast('File picker opened','info')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        <p>Drop files here or <span>browse</span></p>
        <p style="font-size:11px;margin-top:4px;color:var(--text-dim);">PNG, JPG up to 5MB · Multiple allowed</p>
      </div>
    </div>
  </div>`;
}

// ===== SIDEBAR HTML =====
const CURRENT_PAGE = window.location.pathname.split('/').pop();

function isActive(href) {
  return CURRENT_PAGE === href ? 'active' : '';
}

function buildSidebar() {
  const nav = [
    { section: null, items: [
      { href:'index.html', icon:'grid', label:'Dashboard' }
    ]},
    { section: 'Movie Management', items: [
      { href:'movies.html', icon:'film', label:'Movies' },
      { href:'movies.html', icon:'list', label:'Categories' },
      { href:'movies.html', icon:'image', label:'Movie Images' },
      { href:'movies.html', icon:'message', label:'Reviews' },
    ]},
    { section: 'Cinema Management', items: [
      { href:'cinemas.html', icon:'home', label:'Cinemas' },
      { href:'cinemas.html', icon:'monitor', label:'Rooms' },
      { href:'seats.html', icon:'seat', label:'Seats' },
      { href:'showtimes.html', icon:'clock', label:'Showtimes' },
    ]},
    { section: 'Ticket System', items: [
      { href:'ticket-orders.html', icon:'ticket', label:'Ticket Orders', badge:'12' },
      { href:'ticket-orders.html', icon:'doc', label:'Ticket Details' },
    ]},
    { section: 'Shop Management', items: [
      { href:'products.html', icon:'shop', label:'Products' },
      { href:'products.html', icon:'list', label:'Product Categories' },
      { href:'products.html', icon:'image', label:'Product Images' },
    ]},
    { section: 'Shop Orders', items: [
      { href:'shop-orders.html', icon:'clipboard', label:'Shop Orders', badge:'7' },
      { href:'shop-orders.html', icon:'doc', label:'Order Details' },
    ]},
    { section: 'Payments', items: [
      { href:'payments.html', icon:'card', label:'Payment History' },
      { href:'payments.html', icon:'shield', label:'Payment Methods' },
    ]},
    { section: 'Promotions', items: [
      { href:'promotions.html', icon:'heart', label:'Promotions' },
      { href:'promotions.html', icon:'cart', label:'Product Promotions' },
    ]},
    { section: 'Content', items: [
      { href:'index.html', icon:'layout', label:'Banners' },
      { href:'index.html', icon:'bell', label:'Notifications' },
    ]},
    { section: 'User Management', items: [
      { href:'users.html', icon:'users', label:'Users' },
      { href:'users.html', icon:'pin', label:'User Addresses' },
      { href:'users.html', icon:'shield', label:'Roles' },
    ]},
    { section: 'Settings', items: [
      { href:'index.html', icon:'settings', label:'System Settings' },
      { href:'index.html', icon:'user', label:'Admin Profile' },
    ]},
  ];

  const icons = {
    grid:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
    film:'<rect x="2" y="2" width="20" height="20" rx="2"/><path d="M7 2v20M17 2v20M2 12h20M2 7h5M17 7h5M2 17h5M17 17h5"/>',
    list:'<path d="M4 6h16M4 12h16M4 18h7"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
    message:'<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>',
    home:'<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    monitor:'<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
    seat:'<path d="M5 13V7a2 2 0 012-2h10a2 2 0 012 2v6M5 13H3v5h18v-5h-2M5 13h14"/><path d="M8 21v-3M16 21v-3"/>',
    clock:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    ticket:'<path d="M20 12v6a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h6"/><path d="M14.5 4h5.5v5.5"/><path d="M14 10l6-6"/>',
    doc:'<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/>',
    shop:'<path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/>',
    clipboard:'<path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/>',
    card:'<rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/>',
    shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    heart:'<path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>',
    cart:'<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/>',
    layout:'<rect x="3" y="3" width="18" height="5" rx="1"/><rect x="3" y="11" width="7" height="10" rx="1"/><rect x="13" y="11" width="8" height="5" rx="1"/>',
    bell:'<path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/>',
    users:'<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>',
    pin:'<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/>',
    settings:'<circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 010 14.14M4.93 4.93a10 10 0 000 14.14"/>',
    user:'<path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  };

  let html = '';
  nav.forEach(group => {
    html += '<div class="nav-section">';
    if (group.section) html += `<div class="nav-label">${group.section}</div>`;
    group.items.forEach(item => {
      const active = isActive(item.href);
      html += `
        <a href="${item.href}" class="nav-item ${active}" ${active?'':''}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${icons[item.icon]||icons.doc}</svg>
          <span>${item.label}</span>
          ${item.badge ? `<div class="nav-badge">${item.badge}</div>` : ''}
        </a>`;
    });
    html += '</div>';
  });
  return html;
}

// ===== HEADER HTML =====
function buildHeader(quickActionLabel='Quick Add', quickActionFn='showToast("Quick action","info")') {
  return `
  <header class="header">
    <button class="header-toggle" onclick="toggleSidebar()">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
    </button>
    <div class="search-wrap">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
      <input class="search-input" type="text" placeholder="Search movies, users, orders...">
    </div>
    <div class="header-right">
      <button class="header-btn hide-mobile" onclick="showToast('No new messages','info')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
      </button>
      <button class="header-btn" onclick="showToast('3 new notifications','info')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        <div class="notif-dot"></div>
      </button>
      <button class="quick-action-btn" onclick="${quickActionFn}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        <span>${quickActionLabel}</span>
      </button>
      <div class="avatar" onclick="showToast('Profile options','info')">AD</div>
    </div>
  </header>`;
}

// ===== MODAL HTML =====
const MODAL_HTML = `
<div class="modal-overlay" id="modalOverlay">
  <div class="modal" id="modalContent">
    <div class="modal-header">
      <div class="modal-title" id="modalTitle">Modal</div>
      <button class="modal-close" onclick="closeModal()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
      </button>
    </div>
    <div class="modal-body" id="modalBody"></div>
    <div class="modal-footer">
      <button class="btn btn-ghost btn-sm" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary btn-sm" onclick="handleModalSave()">Save Changes</button>
    </div>
  </div>
</div>`;

// ===== INJECT LAYOUT =====
function injectLayout() {
  // Toast
  if (!document.getElementById('toastContainer')) {
    const tc = document.createElement('div');
    tc.className = 'toast-container'; tc.id = 'toastContainer';
    document.body.prepend(tc);
  }
  // Modal
  if (!document.getElementById('modalOverlay')) {
    document.body.insertAdjacentHTML('beforeend', MODAL_HTML);
    document.getElementById('modalOverlay').addEventListener('click', function(e){ if(e.target===this) closeModal(); });
  }
  // Sidebar overlay
  if (!document.getElementById('sidebarOverlay')) {
    const ov = document.createElement('div');
    ov.className = 'sidebar-overlay'; ov.id = 'sidebarOverlay';
    ov.onclick = closeMobileSidebar;
    document.body.prepend(ov);
  }
  // Sidebar nav items
  const sc = document.getElementById('sidebarNav');
  if (sc) sc.innerHTML = buildSidebar();

  // Search
  const si = document.querySelector('.search-input');
  if (si) si.addEventListener('keydown', function(e){ if(e.key==='Enter'&&this.value.trim()) showToast(`Searching "${this.value}"…`,'info'); });

  // Tab buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function(){
      this.closest('.tabs').querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
      this.classList.add('active');
    });
  });
}

document.addEventListener('DOMContentLoaded', injectLayout);
