/* ═══════════════════════════════════════════
   CINEMAX — COMPONENT LOADER
   Load header, sidebar, footer từ file HTML riêng
   và inject vào tất cả các trang.

   Cách dùng trong mỗi trang HTML:
   ─────────────────────────────────────────
   <div id="cx-header"></div>
   <div id="cx-sidebar"></div>
   ... nội dung trang ...
   <div id="cx-footer"></div>

   <script src="components.js"></script>
   <script src="shared.js"></script>
   <script>
     CX.init('home');  // truyền page ID
   </script>
═══════════════════════════════════════════ */

const CX = (() => {

  /* ─── Fetch một file HTML và trả về text ─── */
  async function fetchComponent(path) {
    const res = await fetch(path);
    if (!res.ok) throw new Error(`Cannot load component: ${path}`);
    return res.text();
  }

  /* ─── Inject HTML vào một slot ─── */
  function inject(slotId, html) {
    const slot = document.getElementById(slotId);
    if (!slot) return;
    // Tạo một fragment tạm để parse HTML
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    // Thay thế slot bằng các children của fragment
    slot.replaceWith(...tmp.childNodes);
  }

  /* ─── Đánh dấu nav item active theo page ─── */
  function setActive(pageId) {
    document.querySelectorAll('[data-page]').forEach(el => {
      el.classList.toggle('active', el.dataset.page === pageId);
    });
  }

  /* ─── Khởi tạo sidebar toggle (mobile) ─── */
  function initSidebar() {
    const btn     = document.getElementById('hamburgerBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if (!btn || !sidebar) return;

    const open  = () => { sidebar.classList.add('open');    overlay && overlay.classList.add('active'); };
    const close = () => { sidebar.classList.remove('open'); overlay && overlay.classList.remove('active'); };

    btn.addEventListener('click', () => sidebar.classList.contains('open') ? close() : open());
    overlay && overlay.addEventListener('click', close);

    // Đóng sidebar khi click vào nav item trên mobile
    sidebar.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', () => {
        if (window.innerWidth < 992) close();
      });
    });
  }

  /* ─── Live search trong header ─── */
  function initSearch() {
    const input    = document.getElementById('globalSearch');
    const dropdown = document.getElementById('searchDropdown');
    if (!input || !dropdown) return;

    // Data tổng hợp để search (movies + products từ shared.js)
    function getSearchData() {
      const results = [];
      if (typeof MOVIES !== 'undefined') {
        MOVIES.forEach(m => results.push({ type: 'movie', label: m.title, sub: `${m.genre} · ${m.duration}`, href: 'movie-detail.html', icon: '🎬' }));
      }
      if (typeof PRODUCTS !== 'undefined') {
        PRODUCTS.forEach(p => results.push({ type: 'product', label: p.name, sub: `$${p.price.toFixed(2)}`, href: 'product-detail.html', icon: '🛍️' }));
      }
      return results;
    }

    input.addEventListener('input', () => {
      const q = input.value.trim().toLowerCase();
      if (!q) { dropdown.classList.remove('open'); return; }

      const matches = getSearchData().filter(r => r.label.toLowerCase().includes(q)).slice(0, 7);

      if (!matches.length) {
        dropdown.innerHTML = `<div class="search-empty">No results for "<strong>${q}</strong>"</div>`;
      } else {
        dropdown.innerHTML = matches.map(r => `
          <a href="${r.href}" class="search-result-item">
            <span class="search-result-icon">${r.icon}</span>
            <span class="search-result-info">
              <span class="search-result-label">${highlight(r.label, q)}</span>
              <span class="search-result-sub">${r.sub}</span>
            </span>
          </a>`).join('');
      }
      dropdown.classList.add('open');
    });

    // Đóng dropdown khi click ra ngoài
    document.addEventListener('click', e => {
      if (!input.closest('.header-search').contains(e.target)) {
        dropdown.classList.remove('open');
      }
    });

    input.addEventListener('keydown', e => {
      if (e.key === 'Escape') { dropdown.classList.remove('open'); input.blur(); }
    });
  }

  /* ─── Highlight từ khóa trong kết quả search ─── */
  function highlight(text, query) {
    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    return text.replace(regex, '<mark>$1</mark>');
  }

  /* ─── Update cart badge ─── */
  function updateCartBadges() {
    const count = typeof cartCount === 'function' ? cartCount() : 0;
    document.querySelectorAll('#cartBadge, #cartNavBadge').forEach(el => {
      if (el) {
        el.textContent = count;
        el.style.display = count > 0 ? 'flex' : 'none';
      }
    });
  }

  /* ─── Public init ─── */
  async function init(pageId = '') {
    try {
      // Xác định base path (hỗ trợ cả pages nằm cùng cấp với components/)
      const base = 'components/';

      // Load 3 components song song
      const [headerHTML, sidebarHTML, footerHTML] = await Promise.all([
        fetchComponent(base + 'header.html'),
        fetchComponent(base + 'sidebar.html'),
        fetchComponent(base + 'footer.html'),
      ]);

      inject('cx-header',  headerHTML);
      inject('cx-sidebar', sidebarHTML);
      inject('cx-footer',  footerHTML);

      // Sau khi inject xong thì khởi tạo
      setActive(pageId);
      initSidebar();
      initSearch();
      updateCartBadges();

    } catch (err) {
      console.warn('[CinemaX] Component load error:', err.message);
      // Fallback: vẫn hoạt động, chỉ không có layout
    }
  }

  return { init, updateCartBadges, setActive };

})();
